class Config(object):
    DATABASE_CONFIG = {
    'host': 'localhost',
    'db_name': 'user_rishabh',
    'user': 'root',
    'password': 'PassWord1.'    
    }
